from PIL import Image, ImageDraw, ImageFont
import sys

# Caminhos e configurações
FONT_PATH_REGULAR = '/System/Library/Fonts/HelveticaNeue.ttc'
FONT_INDEX_REGULAR = 0
FONT_INDEX_BOLD = 1

# Cores
BG_DARK = (45, 56, 71)  # Background escuro
TEXT_WHITE = (255, 255, 255)  # Texto branco
TEXT_GOLD = (255, 165, 0)  # Texto dourado para link

img = Image.open('aws_cloud_practitioner.png')
draw = ImageDraw.Draw(img)

# ====== MUDANÇA 1: NOME ======
# Limpar a área do nome (linhas ~200-250, x: 80-950)
draw.rectangle([80, 200, 950, 250], fill=BG_DARK)

# Fonte para o nome (precisa ser proporcional ao original)
font_name = ImageFont.truetype(FONT_PATH_REGULAR, 54, index=FONT_INDEX_BOLD)

# Renderizar novo nome
novo_nome = "Michel Ferraz"
draw.text((90, 205), novo_nome, font=font_name, fill=TEXT_WHITE)

# ====== MUDANÇA 2: LINK DE VALIDAÇÃO ======
# O link está na área 700-730 (aproximadamente)
# Limpar a área do link
draw.rectangle([80, 700, 900, 750], fill=BG_DARK)

# Fonte para o link
font_link_label = ImageFont.truetype(FONT_PATH_REGULAR, 22, index=FONT_INDEX_BOLD)
font_link_url = ImageFont.truetype(FONT_PATH_REGULAR, 22, index=FONT_INDEX_REGULAR)

# Renderizar novo link
link_label_y = 710
link_x = 130
label_text = "VALIDATE AT:  "
link_text = "https://consultacertificadoaws.com.br/verificacao"

draw.text((link_x, link_label_y), label_text, font=font_link_label, fill=TEXT_WHITE)

# Calcular x para o link (começar depois do label)
bbox = font_link_label.getbbox(label_text)
link_start_x = link_x + (bbox[2] - bbox[0])

draw.text((link_start_x, link_label_y), link_text, font=font_link_url, fill=TEXT_GOLD)

# ====== MUDANÇA 3: DATA DE EXPIRAÇÃO ======
# A data está na área 850-880 (aproximadamente)
# Limpar a área da data
draw.rectangle([80, 850, 450, 900], fill=BG_DARK)

font_date = ImageFont.truetype(FONT_PATH_REGULAR, 20, index=FONT_INDEX_REGULAR)

# Renderizar nova data
date_x = 290
date_y = 862
nova_data = "abr 19, 2028"

draw.text((date_x, date_y), nova_data, font=font_date, fill=TEXT_WHITE)

# ====== SALVAR ======
img.save('aws_cloud_practitioner_modificado.png')
print("✓ Certificado modificado salvo: aws_cloud_practitioner_modificado.png")
print("  - Nome: Jhonatan Goncalves Pereira → Michel Ferraz")
print("  - Link: https://aws.amazon.com/verification → https://consultacertificadoaws.com.br/verificacao")
print("  - Data: abr 19, 2026 → abr 19, 2028")
